import express from "express";
import cors from "cors";
import { HumanMessage } from "@langchain/core/messages";
import { createAgent } from "./agent.js";
import { llm } from "./ollama.js";

const app = express();
app.use(cors());
app.use(express.json());

const agent = createAgent(llm);

app.post("/chat", async (req, res) => {
    const messages = req.body.messages || [];

    const result = await agent.invoke({
        messages: messages.map(
            (m) => new HumanMessage({ content: m })
        )
    });

    res.json({
        reply: result.messages.at(-1).content
    });
});

app.listen(3001, () => {
    console.log("Agent server running at http://localhost:3001");
});
