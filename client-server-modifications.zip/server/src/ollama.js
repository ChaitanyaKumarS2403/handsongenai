// ollama.js
import { ChatOllama } from "@langchain/ollama"; // New package

export const llm = new ChatOllama({
    baseUrl: "http://localhost:11434",
    model: "gemma3:4b",
    temperature: 0.7
});